import { createContext } from "react";




const VedioDispatchContext = createContext(null);


export default VedioDispatchContext;








