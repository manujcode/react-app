import { createContext } from "react";



const VedioContext = createContext(null);

// setVideo = (value){
//     VedioContext = value;
// }

export default VedioContext;








