// import { useContext } from "react";
// import VedioContext from "../context/vedioConstext.js";
import PlayButton from "./playButton.js";
import Vedio from "./Vedio.js";
import useVedio from "../hooks/vediohook.js";
import { useCallback, useDeferredValue, useMemo } from "react";
// import axios from "axios";
// import { useEffect, useState } from "react";
// import useVedioDispatch from "../hooks/vedioDispatch.js";
// import { type } from "@testing-library/user-event/dist/type/index.js";
function VedioList() {
  const play = useCallback(() => console.log("play"));
  const pause = useCallback(() => console.log("play"));
  //  const [vedios,setVedio]=useState([])
  // const dispatch = useVedioDispatch();
  // const url = "https://my.api.mockaroo.com/vedio_data.json?key=ef04fb00";
  // async function handleClick(e) {
  //
  // }

  // useEffect(() => {
  //   async function getVedio() {
  //     let xx = await axios.get(url);
  //     console.log(xx)
  //     dispatch({type:'PUT', payload:[...xx.data] });

  //   }
  //   getVedio();
  // }, [dispatch]);
  // const Vedios =useContext(VedioContext);
  const Vedios = useVedio();
  // console.log(Vedios,"jf")
  // const play = useMemo(() => console.log("play"));
  // const pause = useMemo(() => console.log("play"));
  const playButtons =useCallback(<PlayButton
    // name={vedio.title}
    onpause={play}
    offpause={pause}
  ></PlayButton>,[])

   const defVedio=useDeferredValue(Vedios);
  return (
    <>
      {/* <VedioContect.Provider> */}
      {defVedio.map((vedio) => (
        <Vedio
          title={vedio.title}
          channel={vedio.channel}
          views={vedio.views}
          time={vedio.time}
          varified={vedio.varified}
          id={vedio.id}

          //  children={children}
        >
          {playButtons}

        </Vedio>
      ))}

      <button>Get vedios</button>
      {/* </VedioContect.Provider> */}
    </>
  );
}

export default VedioList;
