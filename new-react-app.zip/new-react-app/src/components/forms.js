import axios from "axios";
import "./forms.css";
import { useState } from "react";

const obj = {
  name: "",
  language: "",
  id: "",
  bio: "",
  version: ""
};

// const [vedio, setVedio] = useState(domi);

function Formss() {
  const [object, setObject] = useState(obj);
  function handleChange(e) {
    // console.log('ffegfkuheqrbgfkjhbqekjhfgkuerfbff')
    setObject({ ...object, [e.target.name]: e.target.value });
    console.log(e.target.name, e.target.value);
  }

  const addObject = async () => {
    const res = await axios.post("http://localhost:8800/products/", object);
    console.log(res.data);
  };

  function handleSubmit(e) {
    //  e.preventDefalt();
    e.preventDefault();

    console.log(object);
    addObject();
  }

  return (
    <>
      <form>
        <label>
          Name:
          <input type="text" onChange={handleChange} name="name" />
        </label>
        <label>
          language:
          <input type="text" onChange={handleChange} name="language" />
        </label>
        <label>
          id:
          <input type="text" onChange={handleChange} name="id" />
        </label>
        <label>
          bio:
          <input type="text" onChange={handleChange} name="bio" />
        </label>
        <label>
          version:
          <input type="text" onChange={handleChange} name="version" />
        </label>
        <input type="submit" onClick={ handleSubmit} value="Submit" />
      </form>
    </>
  );
}

export default Formss;
