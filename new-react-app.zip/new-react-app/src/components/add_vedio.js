import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import "./add_vedio.css";
import useVedioDispatch from "../hooks/vedioDispatch";

 const AddVedio=forwardRef(function AddVedio({ editTableVedio},ref) {
    let domi = {
      time: "1 month ago",
      channel: "crazy NITJ",
      varified: true,
      title: "",
      views: "",
    };
    const [vedio, setVedio] = useState(domi);
    // console.log('xxx',vedio,'xxx')

    const dispatch = useVedioDispatch();
    // const inputRef = useRef(null);
  // const dispatch=useContext(VedioDispatchContext);
  // console.log(editTableVedio, "hh");





  
  function handleSubmit(e) {
    e.preventDefault();
    // e.stopPropagation();
    if (editTableVedio) {
      // updateVedio(vedio);
      dispatch({ type: "UPDATE", payload: vedio });
      setVedio(domi);
    } else {
      // dispatch(vedio);
      dispatch({ type: "ADD", payload: vedio });
    }
    //  console.log(vedio)
  }
  
  function handleChange(e) {
    // console.log('ffegfkuheqrbgfkjhbqekjhfgkuerfbff')
    setVedio({ ...vedio, [e.target.name]: e.target.value });
    // console.log(e.target.name, e.target.value);
  }
  //  console.log(editTableVedio,'hhg');

   const iref = useRef(null)

   useImperativeHandle(ref,()=>({
    
      focuss(){
        
           iref.current.focus()
      
    }


   }), [])

  useEffect(() => {
    // console.log('xxmiuhdiuhwiudx',editTableVedio)

    if (editTableVedio) {
      // console.log('ffegfkuheqrbgfkjhbqekjhfgkuerfbff')

      setVedio(editTableVedio);
    }
    // inputRef.current.focus();
  }, [editTableVedio]);

  return (
    <form>
      <input
        ref={iref}
        type="text"
        name="title"
        onChange={handleChange}
        placeholder="tittle"
        value={vedio.title}
      />
      <input
        type="text"
        name="views"
        onChange={handleChange}
        placeholder="views "
        value={vedio.views}
      />

      <button onClick={handleSubmit}>
        {editTableVedio ? "Edit Vedio" : "Add Vedio"}
      </button>
    </form>
  );
})
export default AddVedio;
//omek3y48