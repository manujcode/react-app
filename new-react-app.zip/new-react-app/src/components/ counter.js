import { useCallback, useState } from "react";

import { useMemo } from "react";

function Counter() {
  // function handleClick(e) {
  //   e.stopPropagation();
  //   setNumber((number) => number + 1);
  //   setNumber((number) => number + 1);
  //   setNumber((number) => number + 1);

  //   //  console.log(number)
  // }
  const [number, setNumber] = useState(10);
  // console.log()

  const fibFx = useCallback(function fib(n) {
    // setNumber(3);

    if (n === 0 || n === 1) {
      return 1;
    } else {
      return fib(n - 1) + fib(n - 2);
    }
  },[]);


  const fibMeno = useMemo(() => fibFx(number), [number, fibFx]);
  console.log("fib");
  return (
    <>
      <div>{fibMeno}</div>
      {/* <button onClick={handleClick}> play</button> */}
    </>
  );
}
export default Counter;
