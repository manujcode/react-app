 import { useState,memo } from "react";
import "./playButton.css"

 const PlayButtons= memo(function PlayButton({name,onpause,offpause}){
   const [playing,setPlaying] = useState(false);
    console.log("payButton")
   
    function handleClick(e){
      console.log(e);
      e.stopPropagation();

     if(playing){
        onpause()
     }
     else
     offpause();

   setPlaying(!playing)

    }
return(
  <button  onClick={handleClick}> {playing?"  play  ":"  pause  "}{ name}</button>
   

);

})
export default PlayButtons;