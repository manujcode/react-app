
// import { useContext } from 'react'
import './Vedio.css'
// import VedioDispatchContext from '../context/vedioDispatch'
import useVedioDispatch from '../hooks/vedioDispatch'
import { memo,useLayoutEffect, useRef } from 'react'
const Vedio =memo(function Vedio({ title, channel ,views ,time,varified,children,id=1}){
//  let bg ; 
//  const dispatch =useContext(VedioDispatchContext);
// console.log(children)
const ref =useRef(null)
useLayoutEffect(()=>{
    const { height } = ref.current.getBoundingClientRect();
console.log(height,id);
},[])
const dispatch = useVedioDispatch()
//  console.log(children)÷\
   console.log("vedio",id)
    return(
        <>
        <div  ref ={ref} className='container'>
            <button className='close' onClick={()=>{ dispatch({type:'DELETE',payload:id})}}>x</button>
            <button className='edit' onClick={()=>{ dispatch({type:'EDIT',payload:id})}}>edit</button>
        <div className='pic'>
         
         
         
         <img  style={{display:'block'}}  src={`https://picsum.photos/id/${id}/250/150`} alt=""></img>
        </div>
         <div className='title' > {title}</div>
         
         <div className='channel'>{channel} {varified?"✅":null}</div>
         <div className='views'>
            {views} views <span>.</span> {time}
            </div>
         <div>{children}</div>
         {/* console.log(children)÷ */}
            </div>
        </>
    )
})
export default Vedio;

