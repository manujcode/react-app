import { useContext } from "react";
import VedioDispatchContext from "../context/vedioDispatch";


function useVedioDispatch(){

return useContext(VedioDispatchContext);

 

}
export default useVedioDispatch;