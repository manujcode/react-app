import { useContext } from "react";
import VedioContext from "../context/vedioConstext";


function useVedio(){

return useContext(VedioContext);

}
export default useVedio;