#include<iostream>
#include<string>
 using namespace std;



int main(){

string s;
cin>>s;
int n=s.size();
int m=0;
cin>>m;
for(int i=0;i<n;i++){

   if(s[i]>=65||s[i]<=90){
    
  if(s[i]==90){
    s[i]=65;
  }
  else
    s[i]++;





   }
 if(s[i]>=97||s[i]<=122){
    
  if(s[i]==122){
    s[i]=97;
  }
  else
    s[i]++;





   }



}




cout<<s;


    return 0;
}