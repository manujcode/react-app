// import Vedio from "./components/Vedio.js";
import "./App.css";
// import PlayButton from "./components/playButton.js"
// 7240000499
// import { clear } from "@testing-library/user-event/dist/clear.js";
import Formss from "./components/forms.js"
import AddVedio from "./components/add_vedio.js";
import { useReducer, useState } from "react";
import VedioList from "./components/VedioList.js";
import VedioContect from "./context/vedioConstext";
import VedioDispatchContext from "./context/vedioDispatch";
import Counter from "./components/ counter";
import { useRef } from "react";
function App() {
  // let children = <PlayButton  name = "play" onpause={()=>console.log("play")}  offpause={()=>console.log("pause")}></PlayButton>

  let vedios = [
    {
      title: "React js",
      channel: " Chota bheam",
      views: "10k",
      time: "1 month ago",
      varified: "true",
      id: "1",
    },
    {
      title: "Node js",
      channel: " Mota bheam",
      views: "100k",
      time: "1 year ago",
      varified: "true",
      id: "2",
    },
    {
      title: "Mogo DB",
      channel: " patla bheam",
      views: "10M",
      time: "2 year ago",
      varified: 0,
      id: "3",
    },
  ];

  const [editTableVedio, setEditTableVedio] = useState(null);
  const [vedio, dispatch] = useReducer(vedioReducer, vedios);
  
  function vedioReducer(vedio, action) {
    switch (action.type) {
      // case "PUT":
      //   return action.payload;
      case "ADD":
        return [...vedio, { ...action.payload, id: vedio.length + 1 }];
      case "UPDATE":
        const index = vedio.findIndex((ve) => ve.id === action.payload.id);
        const newVedio = [...vedio];
        newVedio.splice(index, 1, action.payload);
        setEditTableVedio(null);
        return newVedio;
      case "DELETE":
        return [...vedio].filter((vedio) => vedio.id !== action.payload);
      case "EDIT":
        // console.log(action.payload,'yy');
        // console.log("TEMP LOADING START")
        setEditTableVedio(vedio.find((ved) => ved.id === action.payload));
        // console.log("TEMP LOADING ENDS")
        // break;
        return vedio;

      default:
        return vedio;
    }
  }

  // const [vedio,setVedio] = useState(vedios)

  // function addvedio(vediox){
  //   dispatch({type:'ADD',payload:vediox})
  //   // setVedio([...vedio,{...vediox,id:vedio.length+1}])÷

  // }
  // function updateVedio(vedio){
  //       dispatch({type:'UPDATE',payload:vedio})

  //   //     //  console.log(v)
  //   // const index = vedio.findIndex(ve=>ve.id==v.id)
  //   //  const newVedio=[...vedio]
  //   //  newVedio.splice(index,1,v)

  //   //  setVedio(newVedio)
  // }
  //   function deleteVedio(id){
  //     // setVedio([...vedio,{...vediox,id:vedio.length+1}])
  // //  console.log(id);
  //     //  setVedio(vedio.filter(vedio=>vedio.id!==id))
  //     dispatch({type:'DELETE',payload:id})

  //   }
  // function editVedio(id){

  //   //  setVedio(vedio.filter(vedio=>vedio.id!==id))
  //    dispatch({type:'EDIT',payload:id})
  //       // setEditTableVedio(vedio.find(vedio=>vedio.id===id))

  // }
  //  function formShow(e){
  //   console.log("clicked")
  //   // e.preventDefault();
  //   if(e){

  //   return(
  //     <>
  //   <Formss></Formss>
  //   </>
  //   )}
  //   else{
  //     return(
  //     <div>form</div>
  //     )
  //   }
  //  }
  const InputRef =useRef(null);

  return (
    <>
    <div className="form">
      <Counter> </Counter>
   <Formss ></Formss>
   </div>
    <VedioDispatchContext.Provider value={dispatch}>
      <VedioContect.Provider value={vedio}>
        <button onClick={()=>{ InputRef.current.focuss()}}>Focus</button>
        <div className="App" onClick={() => console.log("APP")}>
          <AddVedio
            editTableVedio={editTableVedio}
            ref={InputRef}
          ></AddVedio>
   
          <VedioList></VedioList>
        </div>
      </VedioContect.Provider>
    </VedioDispatchContext.Provider>
   
    </>
  );
} 

export default App;
